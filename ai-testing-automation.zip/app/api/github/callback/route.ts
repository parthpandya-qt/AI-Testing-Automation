import { NextResponse, NextRequest } from "next/server";
import { getAuthenticatedUser } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const code = req.nextUrl.searchParams.get("code");

  if (!code) {
    return NextResponse.redirect(
      new URL("/workspace?error=missing_code", req.url)
    );
  }

  const res = await fetch(
    "https://github.com/login/oauth/access_token",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        client_id: process.env.GITHUB_CLIENT_ID,
        client_secret: process.env.GITHUB_CLIENT_SECRET,
        code,
      }),
    }
  );

  const data = await res.json();

  if (!data) {
    return NextResponse.redirect(
      new URL("/workspace?error=invalid_response", req.url)
    );
  }

  const token = data.access_token;

  if (!token) {
    return NextResponse.redirect(
      new URL("/workspace?error=token_error", req.url)
    );
  }

  const response = NextResponse.redirect(
    new URL("/workspace", req.url)
  );

  const user = await getAuthenticatedUser();
  const cookieOptions = {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 30,
    path: "/",
    sameSite: "lax" as const,
  };

  // Set universal fallback cookie
  response.cookies.set("github_token", token, cookieOptions);

  // Set user-scoped cookie if authenticated user exists
  if (user) {
    response.cookies.set(`github_token_${user.id}`, token, cookieOptions);
  }

  return response;
}