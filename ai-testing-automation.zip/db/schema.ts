import { pgTable, serial, text, timestamp, integer, varchar, jsonb, bigint, index } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name"),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  credits: integer("credits").default(1000).notNull(),
  plan: varchar("plan", { length: 50 }).default("free").notNull(),
  subscriptionStart: timestamp("subscription_start"),
  subscriptionEnd: timestamp("subscription_end"),
  subscriberEmails: text("subscriber_emails")
  .array()
  .notNull()
  .default([]),
});

export const repositories = pgTable("repositories", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  repoId: bigint("repo_id", { mode: "number" }).notNull(),
  name: text("name").notNull(),
  fullName: text("full_name").notNull(),
  private: integer("private").notNull(),
  htmlUrl: text("html_url").notNull(),
  description: text("description"),
  updatedAt: timestamp("updated_at"),
  language: text("language"),
  owner: text("owner").notNull(),
  defaultBranch: text("default_branch").notNull(),
  targetDomain: varchar("target_domain").default('http://localhost:3000/'),
  techStack: varchar("tech_stack", { length: 100 }).default('nextjs'),
  globalInstruction: text("global_instruction"),
}, (table) => [
  index("repositories_repo_id_idx").on(table.repoId),
  index("repositories_user_id_idx").on(table.userId),
]);

export const TestCasesTable = pgTable("test_cases", {
    id: serial("id").primaryKey(),

    // User / project details
    userId: varchar("user_id", { length: 255 }).notNull(),
    repoId: varchar("repo_id", { length: 255 }),
    repoName: varchar("repo_name", { length: 255 }).notNull(),
    repoOwner: varchar("repo_owner", { length: 255 }).notNull(),
    branch: varchar("branch", { length: 100 }).default("main"),
    techStack: varchar("tech_stack", { length: 100 }).default("nextjs"),

    // Main test case data
    title: varchar("title", { length: 500 }).notNull(),
    description: text("description").notNull(),
    type: varchar("type", { length: 100 }).notNull(),
    priority: varchar("priority", { length: 50 }).notNull(),

    // Important metadata for second step: Browserbase script generation
    targetRoute: varchar("target_route", { length: 500 }),

    targetFiles: jsonb("target_files")
        .$type<string[]>()
        .default([]),

    expectedResult: text("expected_result"),

    // Later you can update these fields
    browserbaseScript: text("browserbase_script"),

    status: varchar("status", { length: 100 })
        .default("generated"),
    logs: jsonb("logs").$type<string[]>().default([]),

    sessionId: varchar("session_id", { length: 255 }),

    sessionUrl: text("session_url"),

    createdAt: timestamp("created_at")
        .defaultNow(),
}, (table) => [
  index("test_cases_repo_id_idx").on(table.repoId),
  index("test_cases_user_id_idx").on(table.userId),
]);




export const supportTickets = pgTable(
  "support_tickets",
  {
    id: serial("id").primaryKey(),

    userId: integer("user_id")
      .notNull(),

    subject: text("subject")
      .notNull(),

    category: varchar("category", {
      length: 100,
    }).notNull(),

    description: text("description")
      .notNull(),

    status: varchar("status", {
      length: 50,
    })
      .default("open")
      .notNull(),

    createdAt: timestamp(
      "created_at"
    )
      .defaultNow()
      .notNull(),
  }
);


export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type Repository = typeof repositories.$inferSelect;
export type NewRepository = typeof repositories.$inferInsert;